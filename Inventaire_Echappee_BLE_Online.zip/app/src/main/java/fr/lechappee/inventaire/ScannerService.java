package fr.lechappee.inventaire;

import android.Manifest;
import android.app.*;
import android.bluetooth.*;
import android.bluetooth.le.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.*;

import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.regex.*;

public class ScannerService extends Service {
    public static final String ACTION_SCAN = "fr.lechappee.inventaire.SCAN";
    public static final String EXTRA_CODE = "code";
    private static final String PREFS = "scanner";
    private static final String KEY_MAC = "lastMac";
    private static final UUID CCCD = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");
    private static final int NOTIF_ID = 750;

    public interface Listener {
        void onStatus(String status, boolean connected);
        void onCandidates(List<Candidate> candidates);
    }
    public static class Candidate {
        public final BluetoothDevice device; public final int rssi;
        Candidate(BluetoothDevice d, int r) { device=d; rssi=r; }
        public String label() {
            String n = null;
            try { n = device.getName(); } catch (SecurityException ignored) {}
            if (n == null || n.trim().isEmpty()) n = "Scanner BLE";
            return n + "  (" + rssi + " dBm)";
        }
    }

    public class LocalBinder extends Binder { public ScannerService getService(){ return ScannerService.this; } }
    private final IBinder binder = new LocalBinder();
    private Listener listener;
    private BluetoothAdapter adapter;
    private BluetoothLeScanner leScanner;
    private BluetoothGatt gatt;
    private BluetoothDevice connectedDevice;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final List<Candidate> candidates = new ArrayList<>();
    private final ArrayDeque<BluetoothGattDescriptor> descriptorQueue = new ArrayDeque<>();
    private final StringBuilder rx = new StringBuilder();
    private Runnable flushRunnable;
    private boolean scanning=false, connected=false;

    @Override public void onCreate() {
        super.onCreate();
        BluetoothManager bm=(BluetoothManager)getSystemService(BLUETOOTH_SERVICE);
        adapter=bm!=null?bm.getAdapter():null;
        startInForeground();
        String mac=getSharedPreferences(PREFS,MODE_PRIVATE).getString(KEY_MAC,null);
        if(mac!=null) handler.postDelayed(() -> connectMac(mac), 400);
    }

    private void startInForeground(){
        NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        String channel="c750_scanner";
        if(Build.VERSION.SDK_INT>=26){
            NotificationChannel c=new NotificationChannel(channel,getString(R.string.scanner_channel),NotificationManager.IMPORTANCE_LOW);
            c.setDescription("Connexion Bluetooth au scanner C750");
            nm.createNotificationChannel(c);
        }
        Intent i=new Intent(this,MainActivity.class);
        PendingIntent pi=PendingIntent.getActivity(this,0,i,PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT>=23?PendingIntent.FLAG_IMMUTABLE:0));
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,channel):new Notification.Builder(this);
        b.setContentTitle("Scanner C750 actif").setContentText("Prêt à scanner dans Inventaire ou une autre application")
                .setSmallIcon(R.drawable.ic_notification).setOngoing(true).setContentIntent(pi);
        startForeground(NOTIF_ID,b.build());
    }

    @Override public IBinder onBind(Intent intent){ return binder; }
    @Override public int onStartCommand(Intent intent,int flags,int startId){ return START_STICKY; }
    public void setListener(Listener l){ listener=l; pushStatus(); }
    public boolean isConnected(){ return connected; }
    public String connectedLabel(){
        if(connectedDevice==null) return "Non connecté";
        String n=null; try{n=connectedDevice.getName();}catch(Exception ignored){}
        return n!=null?n:connectedDevice.getAddress();
    }

    private boolean hasBt(){
        if(Build.VERSION.SDK_INT>=31) return checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN)==PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)==PackageManager.PERMISSION_GRANTED;
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED;
    }

    public void startDiscovery(){
        if(adapter==null){ notifyStatus("Bluetooth indisponible",false); return; }
        if(!hasBt()){ notifyStatus("Permission Bluetooth manquante",false); return; }
        if(!adapter.isEnabled()){ notifyStatus("Active le Bluetooth",false); return; }
        if(scanning) return;
        candidates.clear(); scanning=true;
        try{
            leScanner=adapter.getBluetoothLeScanner();
            if(leScanner==null){ scanning=false; notifyStatus("Scanner BLE indisponible",false); return; }
            leScanner.startScan(scanCb);
            notifyStatus("Recherche du C750…",connected);
            handler.postDelayed(this::finishDiscovery,9000);
        }catch(SecurityException e){ scanning=false; notifyStatus("Permission Bluetooth manquante",false); }
    }

    private void finishDiscovery(){
        if(!scanning) return; scanning=false;
        try{ if(leScanner!=null) leScanner.stopScan(scanCb); }catch(Exception ignored){}
        if(listener!=null) listener.onCandidates(new ArrayList<>(candidates));
        if(candidates.isEmpty()) notifyStatus("Aucun C750 trouvé",connected);
        else notifyStatus(candidates.size()+" scanner(s) trouvé(s)",connected);
    }

    private final ScanCallback scanCb=new ScanCallback(){
        @Override public void onScanResult(int callbackType, ScanResult result){
            BluetoothDevice d=result.getDevice(); String name=null;
            try{name=d.getName();}catch(Exception ignored){}
            String low=name==null?"":name.toLowerCase(Locale.ROOT);
            if(!(low.contains("c750")||low.contains("netum")||low.contains("barcode")||low.contains("scanner")||low.contains("rs barcode"))) return;
            for(Candidate c:candidates) if(c.device.getAddress().equals(d.getAddress())) return;
            candidates.add(new Candidate(d,result.getRssi()));
        }
        @Override public void onScanFailed(int errorCode){ scanning=false; notifyStatus("Recherche impossible ("+errorCode+")",connected); }
    };

    public void connectCandidate(Candidate c){ if(c!=null) connectMac(c.device.getAddress()); }
    public void reconnect(){
        String mac=getSharedPreferences(PREFS,MODE_PRIVATE).getString(KEY_MAC,null);
        if(mac!=null) connectMac(mac); else startDiscovery();
    }
    public void connectMac(String mac){
        if(adapter==null||!hasBt()||mac==null) return;
        closeGatt();
        try{
            BluetoothDevice d=adapter.getRemoteDevice(mac); connectedDevice=d;
            notifyStatus("Connexion au C750…",false);
            gatt=Build.VERSION.SDK_INT>=23?d.connectGatt(this,false,gattCb,BluetoothDevice.TRANSPORT_LE):d.connectGatt(this,false,gattCb);
        }catch(Exception e){ notifyStatus("Connexion impossible",false); }
    }

    private final BluetoothGattCallback gattCb=new BluetoothGattCallback(){
        @Override public void onConnectionStateChange(BluetoothGatt g,int status,int newState){
            if(newState==BluetoothProfile.STATE_CONNECTED){
                connected=true;
                try{getSharedPreferences(PREFS,MODE_PRIVATE).edit().putString(KEY_MAC,g.getDevice().getAddress()).apply();}catch(Exception ignored){}
                notifyStatus("C750 connecté — prêt",true);
                try{g.discoverServices();}catch(SecurityException ignored){}
            } else if(newState==BluetoothProfile.STATE_DISCONNECTED){
                connected=false; notifyStatus("C750 déconnecté — reconnexion…",false);
                handler.postDelayed(ScannerService.this::reconnect,2500);
            }
        }
        @Override public void onServicesDiscovered(BluetoothGatt g,int status){ subscribeNotifications(g); }
        @Override public void onDescriptorWrite(BluetoothGatt g,BluetoothGattDescriptor d,int status){ writeNextDescriptor(); }
        @Override public void onCharacteristicChanged(BluetoothGatt g,BluetoothGattCharacteristic c){ onBleBytes(c.getValue()); }
        @Override public void onCharacteristicChanged(BluetoothGatt g,BluetoothGattCharacteristic c,byte[] value){ onBleBytes(value); }
    };

    private void subscribeNotifications(BluetoothGatt g){
        descriptorQueue.clear();
        try{
            for(BluetoothGattService s:g.getServices()) for(BluetoothGattCharacteristic c:s.getCharacteristics()){
                int p=c.getProperties();
                boolean notify=(p&BluetoothGattCharacteristic.PROPERTY_NOTIFY)!=0;
                boolean indicate=(p&BluetoothGattCharacteristic.PROPERTY_INDICATE)!=0;
                if(!notify&&!indicate) continue;
                g.setCharacteristicNotification(c,true);
                BluetoothGattDescriptor d=c.getDescriptor(CCCD);
                if(d!=null){
                    if(Build.VERSION.SDK_INT<33) d.setValue(indicate?BluetoothGattDescriptor.ENABLE_INDICATION_VALUE:BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
                    descriptorQueue.add(d);
                }
            }
            writeNextDescriptor();
        }catch(SecurityException e){ notifyStatus("Canal BLE inaccessible",connected); }
    }

    private void writeNextDescriptor(){
        if(gatt==null||descriptorQueue.isEmpty()) return;
        BluetoothGattDescriptor d=descriptorQueue.poll();
        try{
            byte[] v=((d.getCharacteristic().getProperties()&BluetoothGattCharacteristic.PROPERTY_INDICATE)!=0)?BluetoothGattDescriptor.ENABLE_INDICATION_VALUE:BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE;
            if(Build.VERSION.SDK_INT>=33) gatt.writeDescriptor(d,v); else { d.setValue(v); gatt.writeDescriptor(d); }
        }catch(SecurityException ignored){}
    }

    private synchronized void onBleBytes(byte[] data){
        if(data==null||data.length==0) return;
        String s=new String(data,StandardCharsets.UTF_8);
        boolean ended=s.contains("\n")||s.contains("\r");
        for(int i=0;i<s.length();i++){ char ch=s.charAt(i); if(Character.isDigit(ch)) rx.append(ch); }
        if(flushRunnable!=null) handler.removeCallbacks(flushRunnable);
        flushRunnable=this::flushBarcode;
        handler.postDelayed(flushRunnable,ended?15:100);
    }
    private synchronized void flushBarcode(){
        String code=rx.toString(); rx.setLength(0);
        Matcher m=Pattern.compile("\\d{8,14}").matcher(code);
        if(m.find()){
            code=m.group();
            Intent i=new Intent(ACTION_SCAN).setPackage(getPackageName()).putExtra(EXTRA_CODE,code);
            sendBroadcast(i);
        }
    }

    private void notifyStatus(String s,boolean c){ connected=c; if(listener!=null) handler.post(()->listener.onStatus(s,c)); }
    private void pushStatus(){ if(listener!=null) listener.onStatus(connected?"C750 connecté — prêt":"C750 non connecté",connected); }
    private void closeGatt(){ if(gatt!=null){ try{gatt.disconnect();gatt.close();}catch(Exception ignored){} gatt=null; } connected=false; }
    @Override public void onDestroy(){ handler.removeCallbacksAndMessages(null); finishDiscovery(); closeGatt(); super.onDestroy(); }
}
