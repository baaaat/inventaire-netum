package fr.lechappee.inventaire;

import android.Manifest;
import android.app.*;
import android.bluetooth.BluetoothAdapter;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.text.InputType;
import android.view.*;
import android.widget.*;

import org.json.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity implements ScannerService.Listener {
    private static final int REQ_IMPORT=101, REQ_EXPORT=102, REQ_BT=103;
    private static final int GREEN=Color.rgb(11,138,120), DARK=Color.rgb(28,46,51), BG=Color.rgb(244,247,246), MUTED=Color.rgb(101,116,120);
    private final LinkedHashMap<String,Product> catalog=new LinkedHashMap<>();
    private final LinkedHashMap<String,Integer> inventory=new LinkedHashMap<>();
    private final ArrayDeque<Undo> undo=new ArrayDeque<>();

    private TextView txtStatus,txtUnits,txtRefs,txtUnknown,txtCatalog,txtLast,txtExternal;
    private LinearLayout list;
    private EditText manual;
    private ScannerService scanner;
    private boolean bound=false;
    private BroadcastReceiver scanReceiver;

    static class Product { String ean,name; Product(String e,String n){ean=e;name=n;} }
    static class Undo { String ean; int previous; Undo(String e,int p){ean=e;previous=p;} }

    private final ServiceConnection conn=new ServiceConnection(){
        @Override public void onServiceConnected(ComponentName n, android.os.IBinder b){ scanner=((ScannerService.LocalBinder)b).getService(); bound=true; scanner.setListener(MainActivity.this); }
        @Override public void onServiceDisconnected(ComponentName n){ bound=false; scanner=null; }
    };

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(8,104,91));
        setContentView(buildUi());
        loadAll(); render();
        ensurePermissionsAndStart();
    }

    private View buildUi(){
        ScrollView sv=new ScrollView(this); sv.setFillViewport(true); sv.setBackgroundColor(BG);
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(16),dp(14),dp(16),dp(30)); sv.addView(root,new ScrollView.LayoutParams(-1,-2));

        TextView title=text("Inventaire",28,Color.WHITE,true); title.setPadding(dp(18),dp(18),dp(18),dp(4));
        TextView sub=text("Scanner C750 • inventaire + saisie automatique",14,0xFFD9F3EE,false); sub.setPadding(dp(18),0,dp(18),dp(18));
        LinearLayout hero=new LinearLayout(this); hero.setOrientation(LinearLayout.VERTICAL); hero.setBackground(round(0xFF0B8A78,22)); hero.addView(title); hero.addView(sub); root.addView(hero,lp(-1,-2,0,0,0,12));

        LinearLayout statusCard=card(root);
        txtStatus=text("C750 non connecté",17,DARK,true); statusCard.addView(txtStatus);
        txtExternal=text("Mode externe : à activer",13,MUTED,false); txtExternal.setPadding(0,dp(5),0,dp(10)); statusCard.addView(txtExternal);
        LinearLayout buttons=row();
        buttons.addView(button("Choisir C750",v->chooseScanner()),weight());
        buttons.addView(button("Mode externe",v->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))),weightMargin());
        statusCard.addView(buttons);

        LinearLayout stats=row(); root.addView(stats,lp(-1,-2,0,0,0,12));
        txtUnits=statBox(stats,"0","unités",0); txtRefs=statBox(stats,"0","références",1); txtUnknown=statBox(stats,"0","inconnus",2);

        LinearLayout scanCard=card(root);
        TextView scanTitle=text("Scan manuel",16,DARK,true); scanCard.addView(scanTitle);
        manual=new EditText(this); manual.setHint("EAN"); manual.setSingleLine(true); manual.setInputType(InputType.TYPE_CLASS_NUMBER); manual.setTextSize(18); manual.setPadding(dp(12),dp(10),dp(12),dp(10)); scanCard.addView(manual,lp(-1,-2,0,8,0,8));
        Button add=button("Ajouter",v->{ String e=cleanEan(manual.getText().toString()); if(!e.isEmpty()){processScan(e);manual.setText("");}}); scanCard.addView(add);
        txtLast=text("Prêt pour le premier scan",13,MUTED,false); txtLast.setPadding(0,dp(10),0,0); scanCard.addView(txtLast);

        LinearLayout actions=card(root); txtCatalog=text("Aucun catalogue chargé",14,DARK,true); actions.addView(txtCatalog);
        LinearLayout a1=row(); a1.setPadding(0,dp(10),0,0);
        a1.addView(button("Importer catalogue",v->importCatalog()),weight()); a1.addView(button("Exporter",v->exportInventory()),weightMargin()); actions.addView(a1);
        LinearLayout a2=row(); a2.setPadding(0,dp(8),0,0);
        a2.addView(secondaryButton("Annuler dernier",v->undoLast()),weight()); a2.addView(secondaryButton("Nouvel inventaire",v->confirmReset()),weightMargin()); actions.addView(a2);

        TextView h=text("Articles comptés",18,DARK,true); h.setPadding(dp(2),dp(4),0,dp(8)); root.addView(h);
        list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); root.addView(list);
        return sv;
    }

    private TextView statBox(LinearLayout parent,String val,String label,int idx){
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setGravity(Gravity.CENTER); box.setPadding(dp(8),dp(13),dp(8),dp(13)); box.setBackground(round(Color.WHITE,18));
        TextView v=text(val,24,DARK,true), l=text(label,12,MUTED,false); l.setGravity(Gravity.CENTER); box.addView(v);box.addView(l); parent.addView(box, idx==0?weight():weightMargin()); return v;
    }

    private LinearLayout card(LinearLayout root){ LinearLayout c=new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setPadding(dp(14),dp(14),dp(14),dp(14)); c.setBackground(round(Color.WHITE,18)); root.addView(c,lp(-1,-2,0,0,0,12)); return c; }
    private LinearLayout row(){ LinearLayout r=new LinearLayout(this); r.setOrientation(LinearLayout.HORIZONTAL); r.setGravity(Gravity.CENTER_VERTICAL); return r; }
    private Button button(String s,View.OnClickListener l){ Button b=new Button(this); b.setText(s); b.setTextColor(Color.WHITE); b.setTextSize(14); b.setAllCaps(false); b.setBackground(round(GREEN,14)); b.setOnClickListener(l); return b; }
    private Button secondaryButton(String s,View.OnClickListener l){ Button b=button(s,l); b.setTextColor(DARK); b.setBackground(round(0xFFE8EFED,14)); return b; }
    private TextView text(String s,float size,int color,boolean bold){ TextView t=new TextView(this); t.setText(s);t.setTextSize(size);t.setTextColor(color); if(bold)t.setTypeface(null,1); return t; }
    private GradientDrawable round(int color,int radius){ GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(dp(radius));return g; }
    private LinearLayout.LayoutParams lp(int w,int h,int l,int t,int r,int b){ LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(w,h);p.setMargins(dp(l),dp(t),dp(r),dp(b));return p; }
    private LinearLayout.LayoutParams weight(){ return new LinearLayout.LayoutParams(0,dp(50),1); }
    private LinearLayout.LayoutParams weightMargin(){ LinearLayout.LayoutParams p=weight();p.setMargins(dp(8),0,0,0);return p; }
    private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}

    private void ensurePermissionsAndStart(){
        ArrayList<String> p=new ArrayList<>();
        if(Build.VERSION.SDK_INT>=31){ if(checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN)!=PackageManager.PERMISSION_GRANTED)p.add(Manifest.permission.BLUETOOTH_SCAN); if(checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED)p.add(Manifest.permission.BLUETOOTH_CONNECT); }
        else if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED)p.add(Manifest.permission.ACCESS_FINE_LOCATION);
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)p.add(Manifest.permission.POST_NOTIFICATIONS);
        if(!p.isEmpty()) requestPermissions(p.toArray(new String[0]),REQ_BT); else startScannerService();
    }
    private void startScannerService(){ Intent i=new Intent(this,ScannerService.class); if(Build.VERSION.SDK_INT>=26)startForegroundService(i); else startService(i); bindService(i,conn,BIND_AUTO_CREATE); }
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);if(r==REQ_BT)startScannerService();}

    @Override protected void onStart(){
        super.onStart();
        scanReceiver=new BroadcastReceiver(){@Override public void onReceive(Context c,Intent i){String code=i.getStringExtra(ScannerService.EXTRA_CODE);if(code!=null)processScan(code);}};
        IntentFilter f=new IntentFilter(ScannerService.ACTION_SCAN); if(Build.VERSION.SDK_INT>=33)registerReceiver(scanReceiver,f,Context.RECEIVER_NOT_EXPORTED);else registerReceiver(scanReceiver,f);
    }
    @Override protected void onStop(){ if(scanReceiver!=null){unregisterReceiver(scanReceiver);scanReceiver=null;} super.onStop(); }
    @Override protected void onDestroy(){ if(bound){scanner.setListener(null);unbindService(conn);} super.onDestroy(); }
    @Override protected void onResume(){super.onResume();updateExternalStatus();}

    private void updateExternalStatus(){
        boolean enabled=false; String enabledServices=Settings.Secure.getString(getContentResolver(),Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if(enabledServices!=null) enabled=enabledServices.toLowerCase(Locale.ROOT).contains(getPackageName().toLowerCase(Locale.ROOT));
        if(txtExternal!=null){txtExternal.setText(enabled?"Mode externe : actif — Shifter/Chrome prêts":"Mode externe : désactivé");txtExternal.setTextColor(enabled?GREEN:MUTED);}
    }

    private void chooseScanner(){ if(scanner==null){toast("Service scanner en cours de démarrage");return;} scanner.startDiscovery(); }
    @Override public void onStatus(String s,boolean connected){runOnUiThread(()->{txtStatus.setText(s);txtStatus.setTextColor(connected?GREEN:DARK);});}
    @Override public void onCandidates(List<ScannerService.Candidate> c){runOnUiThread(()->{
        if(c.isEmpty()){toast("Aucun C750 trouvé. Vérifie qu'il est en mode BLE.");return;}
        String[] labels=new String[c.size()];for(int i=0;i<c.size();i++)labels[i]=c.get(i).label();
        new AlertDialog.Builder(this).setTitle("Choisir le scanner").setItems(labels,(d,w)->scanner.connectCandidate(c.get(w))).setNegativeButton("Annuler",null).show();
    });}

    private void processScan(String ean){
        ean=cleanEan(ean); if(ean.length()<8)return;
        Product p=catalog.get(ean); int prev=inventory.containsKey(ean)?inventory.get(ean):0; undo.push(new Undo(ean,prev)); inventory.put(ean,prev+1);
        saveInventory(); txtLast.setText((p!=null?p.name:"EAN inconnu")+"  •  "+ean+"  →  "+(prev+1));
        try{((android.os.Vibrator)getSystemService(VIBRATOR_SERVICE)).vibrate(Build.VERSION.SDK_INT>=26?android.os.VibrationEffect.createOneShot(35,80):35);}catch(Exception ignored){}
        render();
    }
    private String cleanEan(String s){return s==null?"":s.replaceAll("[^0-9]","");}
    private void changeQty(String ean,int delta){int prev=inventory.getOrDefault(ean,0);undo.push(new Undo(ean,prev));int n=Math.max(0,prev+delta);if(n==0)inventory.remove(ean);else inventory.put(ean,n);saveInventory();render();}
    private void undoLast(){if(undo.isEmpty()){toast("Rien à annuler");return;}Undo u=undo.pop();if(u.previous==0)inventory.remove(u.ean);else inventory.put(u.ean,u.previous);saveInventory();txtLast.setText("Dernier scan annulé");render();}
    private void confirmReset(){new AlertDialog.Builder(this).setTitle("Nouvel inventaire ?").setMessage("Toutes les quantités seront effacées. Le catalogue restera chargé.").setPositiveButton("Tout effacer",(d,w)->{inventory.clear();undo.clear();saveInventory();render();}).setNegativeButton("Annuler",null).show();}

    private void render(){
        int units=0,unknown=0;for(Map.Entry<String,Integer>e:inventory.entrySet()){units+=e.getValue();if(!catalog.containsKey(e.getKey()))unknown++;}
        txtUnits.setText(String.valueOf(units));txtRefs.setText(String.valueOf(inventory.size()));txtUnknown.setText(String.valueOf(unknown));txtCatalog.setText(catalog.isEmpty()?"Aucun catalogue chargé":catalog.size()+" articles chargés");
        list.removeAllViews(); if(inventory.isEmpty()){TextView e=text("Aucun article compté. Connecte le C750 puis commence à scanner.",14,MUTED,false);e.setPadding(dp(10),dp(16),dp(10),dp(16));list.addView(e);return;}
        ArrayList<String> keys=new ArrayList<>(inventory.keySet()); Collections.sort(keys,(a,b)->{
            Product pa=catalog.get(a),pb=catalog.get(b);String na=pa!=null?pa.name:a,nb=pb!=null?pb.name:b;return na.compareToIgnoreCase(nb);
        });
        for(String ean:keys){
            Product p=catalog.get(ean);int q=inventory.get(ean);
            LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(dp(13),dp(12),dp(13),dp(12));c.setBackground(round(Color.WHITE,16));list.addView(c,lp(-1,-2,0,0,0,8));
            TextView n=text(p!=null?p.name:"EAN INCONNU",15,p!=null?DARK:0xFFB4552D,true);c.addView(n);TextView code=text(ean,12,MUTED,false);code.setPadding(0,dp(3),0,dp(8));c.addView(code);
            LinearLayout rr=row();TextView qty=text("Quantité  "+q,18,GREEN,true);rr.addView(qty,new LinearLayout.LayoutParams(0,-2,1));Button minus=secondaryButton("−",v->changeQty(ean,-1));Button plus=button("+",v->changeQty(ean,1));LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(dp(52),dp(44));rr.addView(minus,bp);LinearLayout.LayoutParams bp2=new LinearLayout.LayoutParams(dp(52),dp(44));bp2.setMargins(dp(7),0,0,0);rr.addView(plus,bp2);c.addView(rr);
        }
    }

    private void importCatalog(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("text/*");startActivityForResult(i,REQ_IMPORT);}
    private void exportInventory(){Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("text/plain");i.putExtra(Intent.EXTRA_TITLE,"inventaire-"+new SimpleDateFormat("yyyy-MM-dd",Locale.FRANCE).format(new Date())+".txt");startActivityForResult(i,REQ_EXPORT);}
    @Override protected void onActivityResult(int req,int res,Intent data){super.onActivityResult(req,res,data);if(res!=RESULT_OK||data==null||data.getData()==null)return;try{if(req==REQ_IMPORT)readCatalog(data.getData());else if(req==REQ_EXPORT)writeExport(data.getData());}catch(Exception e){toast((req==REQ_IMPORT?"Import":"Export")+" impossible : "+e.getMessage());}}

    private void readCatalog(Uri uri)throws Exception{
        LinkedHashMap<String,Product> fresh=new LinkedHashMap<>();
        BufferedReader br=new BufferedReader(new InputStreamReader(getContentResolver().openInputStream(uri),StandardCharsets.UTF_8));String line;boolean first=true;
        while((line=br.readLine())!=null){if(first&&line.startsWith("\uFEFF"))line=line.substring(1);first=false;List<String> cells=parseCsvLine(line);if(cells.size()<3)continue;String e=cleanEan(cells.get(0));if(e.length()<8)continue;String name=cells.get(2).trim();if(name.isEmpty())name=e;fresh.put(e,new Product(e,name));}br.close();
        catalog.clear();catalog.putAll(fresh);saveCatalog();render();toast(catalog.size()+" articles importés");
    }
    private List<String> parseCsvLine(String line){
        char sep=line.indexOf(';')>=0?';':',';ArrayList<String> out=new ArrayList<>();StringBuilder cur=new StringBuilder();boolean quote=false;
        for(int i=0;i<line.length();i++){char ch=line.charAt(i);if(ch=='\"'){if(quote&&i+1<line.length()&&line.charAt(i+1)=='\"'){cur.append('\"');i++;}else quote=!quote;}else if(ch==sep&&!quote){out.add(cur.toString());cur.setLength(0);}else cur.append(ch);}out.add(cur.toString());return out;
    }
    private void writeExport(Uri uri)throws Exception{
        OutputStreamWriter w=new OutputStreamWriter(getContentResolver().openOutputStream(uri),StandardCharsets.UTF_8);w.write("EAN;Designation;Quantite\n");for(Map.Entry<String,Integer>e:inventory.entrySet()){Product p=catalog.get(e.getKey());String n=p!=null?p.name:"EAN INCONNU";w.write(e.getKey()+";\""+n.replace("\"","\"\"")+"\";"+e.getValue()+"\n");}w.close();toast("Inventaire exporté");
    }

    private File file(String n){return new File(getFilesDir(),n);}
    private void saveCatalog(){try{JSONArray a=new JSONArray();for(Product p:catalog.values()){JSONObject o=new JSONObject();o.put("ean",p.ean);o.put("name",p.name);a.put(o);}writeText(file("catalog.json"),a.toString());}catch(Exception ignored){}}
    private void saveInventory(){try{JSONObject o=new JSONObject();for(Map.Entry<String,Integer>e:inventory.entrySet())o.put(e.getKey(),e.getValue());writeText(file("inventory.json"),o.toString());}catch(Exception ignored){}}
    private void loadAll(){try{File f=file("catalog.json");if(f.exists()){JSONArray a=new JSONArray(readText(f));for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);String e=o.getString("ean");catalog.put(e,new Product(e,o.optString("name",e)));}}}catch(Exception ignored){}try{File f=file("inventory.json");if(f.exists()){JSONObject o=new JSONObject(readText(f));Iterator<String>it=o.keys();while(it.hasNext()){String e=it.next();inventory.put(e,o.optInt(e,0));}}}catch(Exception ignored){}}
    private String readText(File f)throws Exception{BufferedReader b=new BufferedReader(new InputStreamReader(new FileInputStream(f),StandardCharsets.UTF_8));StringBuilder s=new StringBuilder();String l;while((l=b.readLine())!=null)s.append(l);b.close();return s.toString();}
    private void writeText(File f,String s)throws Exception{OutputStreamWriter w=new OutputStreamWriter(new FileOutputStream(f),StandardCharsets.UTF_8);w.write(s);w.close();}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
}
