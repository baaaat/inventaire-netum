package fr.lechappee.inventaire;

import android.accessibilityservice.AccessibilityService;
import android.content.*;
import android.os.*;
import android.view.accessibility.*;

public class ScannerAccessibilityService extends AccessibilityService {
    private BroadcastReceiver receiver;
    @Override public void onServiceConnected(){
        receiver=new BroadcastReceiver(){ @Override public void onReceive(Context c,Intent i){
            if(!ScannerService.ACTION_SCAN.equals(i.getAction())) return;
            String code=i.getStringExtra(ScannerService.EXTRA_CODE); if(code!=null) inject(code);
        }};
        IntentFilter f=new IntentFilter(ScannerService.ACTION_SCAN);
        if(Build.VERSION.SDK_INT>=33) registerReceiver(receiver,f,Context.RECEIVER_NOT_EXPORTED); else registerReceiver(receiver,f);
    }
    private void inject(String code){
        AccessibilityNodeInfo root=getRootInActiveWindow(); if(root==null) return;
        CharSequence pkg=root.getPackageName();
        if(pkg!=null && pkg.toString().equals(getPackageName())) return;
        AccessibilityNodeInfo node=root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT);
        if(node==null || !node.isEditable()) return;
        CharSequence old=node.getText(); String text=old==null?code:old.toString()+code;
        Bundle b=new Bundle(); b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,text);
        if(node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT,b) && Build.VERSION.SDK_INT>=30){
            node.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.getId());
        }
    }
    @Override public void onAccessibilityEvent(AccessibilityEvent event){}
    @Override public void onInterrupt(){}
    @Override public void onDestroy(){ if(receiver!=null) unregisterReceiver(receiver); super.onDestroy(); }
}
