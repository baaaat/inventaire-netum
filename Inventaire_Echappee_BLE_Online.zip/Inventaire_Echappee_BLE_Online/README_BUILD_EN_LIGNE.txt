INVENTAIRE ÉCHAPPÉE — CONSTRUCTION EN LIGNE
===========================================

AUCUN ANDROID STUDIO N'EST NÉCESSAIRE.
Le projet est compilé gratuitement sur GitHub Actions.

1. Aller sur https://github.com et se connecter/créer un compte.
2. Cliquer sur New repository.
   Nom conseillé : inventaire-echappee
   Choisir Private si vous ne voulez pas rendre le code public.
3. Dans le dépôt vide : Add file > Upload files.
   Glisser TOUT LE CONTENU de ce dossier, y compris :
     - app/
     - .github/
     - build.gradle
     - settings.gradle
     - gradle.properties
   Puis cliquer sur Commit changes.
4. Ouvrir l'onglet Actions du dépôt.
   Choisir « Construire APK ».
   Si nécessaire cliquer sur Run workflow > Run workflow.
5. Attendre environ 2 à 5 minutes.
6. Ouvrir l'exécution terminée (coche verte).
7. En bas de la page, dans Artifacts, télécharger :
      Inventaire-Echappee-APK
8. Décompresser le ZIP téléchargé : il contient app-debug.apk.
9. Copier app-debug.apk sur la tablette Samsung et l'installer.
   Android peut demander d'autoriser l'installation d'applications inconnues.

PREMIER DÉMARRAGE
=================
1. Mettre le NETUM C750 en mode Bluetooth BLE.
2. Fermer Scanner Studio s'il est ouvert.
3. Lancer Inventaire Échappée.
4. Autoriser les permissions Bluetooth demandées.
5. Appuyer sur « Connecter C750 ».
6. Choisir le NETUM C750 s'il n'est pas sélectionné automatiquement.
7. Attendre « C750 connecté — prêt à scanner ».
8. Scanner un code pour vérifier la réception.
9. Importer le catalogue CSV depuis la tablette.
   Format : EAN colonne 1, désignation colonne 3.

Le fonctionnement est entièrement local sur la tablette :
- pas de site web ;
- pas d'OVH ;
- pas de Cloudflare ;
- pas de clavier HID ;
- pas de PC à laisser allumé.

Pour une nouvelle version ultérieure, il suffira de remplacer les fichiers du dépôt ;
GitHub reconstruira automatiquement un nouvel APK.
