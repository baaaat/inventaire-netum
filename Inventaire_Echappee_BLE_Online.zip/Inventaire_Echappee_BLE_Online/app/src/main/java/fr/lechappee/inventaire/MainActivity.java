package fr.lechappee.inventaire;

import android.Manifest;
import android.app.*;
import android.bluetooth.*;
import android.bluetooth.le.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.*;

import org.json.*;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.*;

public class MainActivity extends Activity {
    private static final int REQ_BT = 41;
    private static final int REQ_IMPORT = 42;
    private static final int REQ_EXPORT = 43;
    private static final UUID CCCD = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");

    static class Product { String ean, name; Product(String e, String n){ean=e;name=n;} }
    static class Inv { String ean, name; int qty; long updated; Inv(String e,String n,int q,long u){ean=e;name=n;qty=q;updated=u;} }
    static class Undo { String ean; Inv previous; Undo(String e, Inv p){ean=e;previous=p;} }
    static class Candidate { BluetoothDevice d; int rssi; Candidate(BluetoothDevice d,int r){this.d=d;rssi=r;} }

    private final LinkedHashMap<String,Product> catalog = new LinkedHashMap<>();
    private final LinkedHashMap<String,Inv> inventory = new LinkedHashMap<>();
    private final LinkedHashMap<String,Candidate> candidates = new LinkedHashMap<>();
    private final ArrayDeque<BluetoothGattDescriptor> descriptorQueue = new ArrayDeque<>();
    private final StringBuilder rx = new StringBuilder();
    private final Handler handler = new Handler(Looper.getMainLooper());

    private BluetoothAdapter adapter;
    private BluetoothLeScanner leScanner;
    private BluetoothGatt gatt;
    private boolean scanning = false;
    private Runnable flushRx;
    private Undo undo;

    private TextView txtBluetooth, txtLast, txtUnits, txtRefs, txtUnknown, txtCatalog;
    private LinearLayout itemList;
    private EditText search, manualEan;
    private Button btnBluetooth, btnUndo;
    private String filter = "";

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        txtBluetooth=findViewById(R.id.txtBluetooth); txtLast=findViewById(R.id.txtLast);
        txtUnits=findViewById(R.id.txtUnits); txtRefs=findViewById(R.id.txtRefs); txtUnknown=findViewById(R.id.txtUnknown);
        txtCatalog=findViewById(R.id.txtCatalog); itemList=findViewById(R.id.itemList); search=findViewById(R.id.search);
        manualEan=findViewById(R.id.manualEan); btnBluetooth=findViewById(R.id.btnBluetooth); btnUndo=findViewById(R.id.btnUndo);

        BluetoothManager bm=(BluetoothManager)getSystemService(BLUETOOTH_SERVICE); adapter=bm.getAdapter();
        loadAll(); render();

        btnBluetooth.setOnClickListener(v -> ensureBluetoothAndScan());
        findViewById(R.id.btnImport).setOnClickListener(v -> importCsv());
        findViewById(R.id.btnExport).setOnClickListener(v -> exportInventory());
        findViewById(R.id.btnManual).setOnClickListener(v -> { processScan(manualEan.getText().toString()); manualEan.setText(""); });
        btnUndo.setOnClickListener(v -> undoLast());
        findViewById(R.id.btnReset).setOnClickListener(v -> confirmReset());
        search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){} public void onTextChanged(CharSequence s,int st,int b,int c){filter=s.toString().toLowerCase(Locale.ROOT).trim(); renderItems();} public void afterTextChanged(Editable e){} });

        String lastMac=getPreferences(MODE_PRIVATE).getString("lastMac","");
        if(!lastMac.isEmpty()) txtBluetooth.setText("Prêt à reconnecter le C750");
    }

    private boolean hasBtPermissions(){
        if(Build.VERSION.SDK_INT>=31) return checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN)==PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)==PackageManager.PERMISSION_GRANTED;
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED;
    }
    private void requestBtPermissions(){
        if(Build.VERSION.SDK_INT>=31) requestPermissions(new String[]{Manifest.permission.BLUETOOTH_SCAN,Manifest.permission.BLUETOOTH_CONNECT},REQ_BT);
        else requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION},REQ_BT);
    }
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){ super.onRequestPermissionsResult(r,p,g); if(r==REQ_BT && hasBtPermissions()) ensureBluetoothAndScan(); }

    private void ensureBluetoothAndScan(){
        if(adapter==null){toast("Cette tablette n'a pas de Bluetooth");return;}
        if(!hasBtPermissions()){requestBtPermissions();return;}
        try {
            if(!adapter.isEnabled()){ startActivity(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS)); toast("Active le Bluetooth puis reviens dans l’appli"); return; }
        } catch(SecurityException e){requestBtPermissions();return;}
        startBleScan();
    }

    @SuppressWarnings("MissingPermission")
    private void startBleScan(){
        if(scanning){ try{leScanner.stopScan(scanCb);}catch(Exception ignored){} scanning=false; }
        candidates.clear();
        leScanner=adapter.getBluetoothLeScanner();
        if(leScanner==null){toast("Bluetooth BLE indisponible");return;}
        txtBluetooth.setText("Recherche du C750…"); btnBluetooth.setText("Recherche…"); scanning=true;
        leScanner.startScan(scanCb);
        handler.postDelayed(this::finishScan,6500);
    }

    private final ScanCallback scanCb=new ScanCallback(){
        @Override public void onScanResult(int callbackType, ScanResult result){
            BluetoothDevice d=result.getDevice(); if(d==null)return;
            String mac=d.getAddress(); Candidate old=candidates.get(mac); if(old==null || result.getRssi()>old.rssi) candidates.put(mac,new Candidate(d,result.getRssi()));
            String name=safeName(d);
            if(isLikelyNetum(name) && gatt==null){ handler.removeCallbacksAndMessages(null); finishScan(); connect(d); }
        }
        @Override public void onScanFailed(int errorCode){ scanning=false; btnBluetooth.setText("Connecter C750"); txtBluetooth.setText("Recherche impossible ("+errorCode+")"); }
    };

    @SuppressWarnings("MissingPermission")
    private String safeName(BluetoothDevice d){ try { String n=d.getName(); return n==null?"Appareil BLE":n; } catch(Exception e){return "Appareil BLE";} }
    private boolean isLikelyNetum(String n){ String s=n.toLowerCase(Locale.ROOT); return s.contains("c750")||s.contains("netum")||s.contains("rs barcode")||s.contains("barcode scanner"); }

    @SuppressWarnings("MissingPermission")
    private void finishScan(){
        if(scanning){ try{leScanner.stopScan(scanCb);}catch(Exception ignored){} scanning=false; }
        btnBluetooth.setText("Connecter C750");
        if(gatt!=null)return;
        if(candidates.isEmpty()){ txtBluetooth.setText("C750 non trouvé"); toast("Vérifie que le C750 est en mode BLE et ferme Scanner Studio"); return; }
        ArrayList<Candidate> list=new ArrayList<>(candidates.values()); list.sort((a,b)->Integer.compare(b.rssi,a.rssi));
        String[] labels=new String[list.size()];
        for(int i=0;i<list.size();i++) labels[i]=safeName(list.get(i).d)+"   "+list.get(i).d.getAddress()+"   ("+list.get(i).rssi+" dBm)";
        new AlertDialog.Builder(this).setTitle("Choisir le scanner").setItems(labels,(d,w)->connect(list.get(w).d)).setNegativeButton("Annuler",null).show();
    }

    @SuppressWarnings("MissingPermission")
    private void connect(BluetoothDevice device){
        closeGatt(); txtBluetooth.setText("Connexion à "+safeName(device)+"…");
        if(Build.VERSION.SDK_INT>=23) gatt=device.connectGatt(this,false,gattCb,BluetoothDevice.TRANSPORT_LE);
        else gatt=device.connectGatt(this,false,gattCb);
    }

    private final BluetoothGattCallback gattCb=new BluetoothGattCallback(){
        @Override public void onConnectionStateChange(BluetoothGatt g,int status,int newState){
            runOnUiThread(()->{
                if(newState==BluetoothProfile.STATE_CONNECTED){
                    txtBluetooth.setText("C750 connecté — préparation…");
                    try{ getPreferences(MODE_PRIVATE).edit().putString("lastMac",g.getDevice().getAddress()).apply(); }catch(Exception ignored){}
                    try{g.discoverServices();}catch(SecurityException e){txtBluetooth.setText("Permission Bluetooth manquante");}
                } else if(newState==BluetoothProfile.STATE_DISCONNECTED){
                    txtBluetooth.setText("Scanner déconnecté"); btnBluetooth.setText("Reconnecter C750"); if(MainActivity.this.gatt==g) MainActivity.this.gatt=null;
                }
            });
        }
        @Override public void onServicesDiscovered(BluetoothGatt g,int status){ runOnUiThread(()->subscribeNotifications(g)); }
        @Override public void onDescriptorWrite(BluetoothGatt g,BluetoothGattDescriptor d,int status){ runOnUiThread(()->writeNextDescriptor(g)); }
        @Override public void onCharacteristicChanged(BluetoothGatt g,BluetoothGattCharacteristic c){ byte[] v=c.getValue(); onBleBytes(v); }
        @Override public void onCharacteristicChanged(BluetoothGatt g,BluetoothGattCharacteristic c,byte[] value){ onBleBytes(value); }
    };

    @SuppressWarnings("MissingPermission")
    private void subscribeNotifications(BluetoothGatt g){
        descriptorQueue.clear(); int count=0;
        for(BluetoothGattService s:g.getServices()) for(BluetoothGattCharacteristic c:s.getCharacteristics()){
            int p=c.getProperties(); if((p & (BluetoothGattCharacteristic.PROPERTY_NOTIFY|BluetoothGattCharacteristic.PROPERTY_INDICATE))!=0){
                try{g.setCharacteristicNotification(c,true);}catch(Exception ignored){}
                BluetoothGattDescriptor d=c.getDescriptor(CCCD); if(d!=null){ descriptorQueue.add(d); count++; }
            }
        }
        if(count==0){ txtBluetooth.setText("Connecté, mais canal de données introuvable"); toast("Réessaie après avoir fermé Scanner Studio"); }
        else { txtBluetooth.setText("C750 connecté — activation du canal…"); writeNextDescriptor(g); }
    }

    @SuppressWarnings("MissingPermission")
    private void writeNextDescriptor(BluetoothGatt g){
        BluetoothGattDescriptor d=descriptorQueue.poll();
        if(d==null){ txtBluetooth.setText("C750 connecté — prêt à scanner"); btnBluetooth.setText("Reconnecter C750"); return; }
        BluetoothGattCharacteristic c=d.getCharacteristic(); boolean indicate=(c.getProperties() & BluetoothGattCharacteristic.PROPERTY_INDICATE)!=0 && (c.getProperties() & BluetoothGattCharacteristic.PROPERTY_NOTIFY)==0;
        byte[] value=indicate?BluetoothGattDescriptor.ENABLE_INDICATION_VALUE:BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE;
        boolean started;
        if(Build.VERSION.SDK_INT>=33) started=g.writeDescriptor(d,value)==BluetoothStatusCodes.SUCCESS;
        else { d.setValue(value); started=g.writeDescriptor(d); }
        if(!started) handler.postDelayed(()->writeNextDescriptor(g),80);
    }

    private synchronized void onBleBytes(byte[] data){
        if(data==null||data.length==0)return;
        String part=new String(data,StandardCharsets.UTF_8);
        rx.append(part);
        String current=rx.toString();
        if(current.contains("\r")||current.contains("\n")) flushBarcodeBuffer();
        else {
            if(flushRx!=null) handler.removeCallbacks(flushRx);
            flushRx=this::flushBarcodeBuffer; handler.postDelayed(flushRx,140);
        }
    }
    private synchronized void flushBarcodeBuffer(){
        if(flushRx!=null) handler.removeCallbacks(flushRx); flushRx=null;
        String s=rx.toString(); rx.setLength(0);
        Matcher m=Pattern.compile("\\d{8,14}").matcher(s);
        boolean any=false; while(m.find()){ any=true; String code=m.group(); runOnUiThread(()->processScan(code)); }
        if(!any && !s.trim().isEmpty()) runOnUiThread(()->toast("Donnée BLE reçue mais EAN non reconnu : "+s.trim()));
    }

    private void processScan(String raw){
        String ean=raw==null?"":raw.replaceAll("[^0-9]","");
        if(!ean.matches("\\d{8,14}")){ txtLast.setText("Code invalide : "+raw); vibrate(new long[]{0,70,45,70}); return; }
        Inv old=inventory.get(ean); Inv snapshot=old==null?null:new Inv(old.ean,old.name,old.qty,old.updated);
        Product p=catalog.get(ean); String name=p!=null?p.name:(old!=null?old.name:"EAN inconnu");
        Inv now=new Inv(ean,name,old==null?1:old.qty+1,System.currentTimeMillis()); inventory.put(ean,now); undo=new Undo(ean,snapshot);
        txtLast.setText((p!=null?(old==null?"AJOUTÉ":"QUANTITÉ +1"):"EAN INCONNU")+"\n"+name+"\n"+ean+"   ·   QTÉ "+now.qty);
        saveInventory(); render(); vibrate(new long[]{0,35});
    }

    private void undoLast(){ if(undo==null){toast("Rien à annuler");return;} if(undo.previous==null)inventory.remove(undo.ean); else inventory.put(undo.ean,undo.previous); undo=null; saveInventory(); txtLast.setText("Dernier scan annulé"); render(); }
    private void confirmReset(){ new AlertDialog.Builder(this).setTitle("Nouvel inventaire ?").setMessage("Toutes les quantités seront effacées. Le catalogue restera chargé.").setNegativeButton("Annuler",null).setPositiveButton("Tout effacer",(d,w)->{inventory.clear();undo=null;saveInventory();txtLast.setText("Prêt pour le premier scan");render();}).show(); }

    private void importCsv(){ Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("text/*"); i.addCategory(Intent.CATEGORY_OPENABLE); startActivityForResult(i,REQ_IMPORT); }
    private void exportInventory(){ Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT); i.setType("text/plain"); i.putExtra(Intent.EXTRA_TITLE,"inventaire-"+new SimpleDateFormat("yyyy-MM-dd",Locale.FRANCE).format(new Date())+".txt"); startActivityForResult(i,REQ_EXPORT); }

    @Override protected void onActivityResult(int r,int result,Intent data){ super.onActivityResult(r,result,data); if(result!=RESULT_OK||data==null||data.getData()==null)return; Uri uri=data.getData(); if(r==REQ_IMPORT) readCatalog(uri); else if(r==REQ_EXPORT) writeExport(uri); }

    private void readCatalog(Uri uri){
        try(InputStream in=getContentResolver().openInputStream(uri); BufferedReader br=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8))){
            LinkedHashMap<String,Product> next=new LinkedHashMap<>(); String line; boolean first=true;
            while((line=br.readLine())!=null){ if(first){line=line.replace("\uFEFF","");first=false;} List<String> cells=parseCsvLine(line); if(cells.size()<3)continue; String e=cleanEan(cells.get(0)); String n=cells.get(2).trim(); if(e.matches("\\d{8,14}")&&!n.isEmpty())next.put(e,new Product(e,n)); }
            if(next.isEmpty()){toast("Aucun article reconnu. EAN attendu en colonne 1, désignation en colonne 3.");return;}
            catalog.clear(); catalog.putAll(next); for(Inv inv:inventory.values()){Product p=catalog.get(inv.ean);inv.name=p!=null?p.name:"EAN inconnu";}
            String label=uri.getLastPathSegment(); txtCatalog.setText((label==null?"Catalogue":label)+" · "+catalog.size()+" articles"); getPreferences(MODE_PRIVATE).edit().putString("catalogLabel",txtCatalog.getText().toString()).apply();
            saveCatalog();saveInventory();render();toast(catalog.size()+" articles chargés");
        }catch(Exception e){toast("Import impossible : "+e.getMessage());}
    }
    private static List<String> parseCsvLine(String line){ ArrayList<String> out=new ArrayList<>(); StringBuilder f=new StringBuilder(); boolean q=false; for(int i=0;i<line.length();i++){char c=line.charAt(i); if(c=='\"'){if(q&&i+1<line.length()&&line.charAt(i+1)=='\"'){f.append('\"');i++;}else q=!q;} else if(c==','&&!q){out.add(f.toString());f.setLength(0);}else f.append(c);} out.add(f.toString());return out; }
    private static String cleanEan(String v){ return v==null?"":v.trim().replaceFirst("^=\\\"?","").replaceFirst("\\\"$","").trim(); }

    private void writeExport(Uri uri){
        ArrayList<Inv> list=new ArrayList<>(inventory.values()); list.sort(Comparator.comparing(a->a.ean)); StringBuilder s=new StringBuilder(); for(Inv i:list)s.append(i.ean).append(',').append(i.qty).append(';');
        try(OutputStream out=getContentResolver().openOutputStream(uri)){out.write(s.toString().getBytes(StandardCharsets.UTF_8));toast("inventaire.txt créé");}catch(Exception e){toast("Export impossible : "+e.getMessage());}
    }

    private void render(){ int units=0,unknown=0; for(Inv i:inventory.values()){units+=i.qty;if("EAN inconnu".equals(i.name))unknown++;} txtUnits.setText(units+"\nunités");txtRefs.setText(inventory.size()+"\nréférences");txtUnknown.setText(unknown+"\ninconnus");btnUndo.setEnabled(undo!=null);renderItems(); }
    private void renderItems(){
        itemList.removeAllViews(); ArrayList<Inv> list=new ArrayList<>(inventory.values()); list.sort((a,b)->Long.compare(b.updated,a.updated)); int shown=0;
        for(Inv inv:list){String hay=(inv.ean+" "+inv.name).toLowerCase(Locale.ROOT);if(!filter.isEmpty()&&!hay.contains(filter))continue;shown++;
            LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setPadding(8,10,8,10);
            LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2);rp.setMargins(0,2,0,2);row.setLayoutParams(rp);row.setBackgroundColor(getColor(android.R.color.white));
            TextView copy=new TextView(this);copy.setText(inv.name+"\n"+inv.ean);copy.setTextSize(16);copy.setTextColor(getColor(R.color.ink));copy.setPadding(6,4,6,4);row.addView(copy,new LinearLayout.LayoutParams(0,-2,1));
            Button minus=new Button(this);minus.setText("−");minus.setOnClickListener(v->changeQty(inv.ean,-1));row.addView(minus,new LinearLayout.LayoutParams(72,-2));
            TextView q=new TextView(this);q.setText(String.valueOf(inv.qty));q.setGravity(17);q.setTextSize(18);q.setTextColor(getColor(R.color.ink));row.addView(q,new LinearLayout.LayoutParams(60,-1));
            Button plus=new Button(this);plus.setText("+");plus.setOnClickListener(v->changeQty(inv.ean,1));row.addView(plus,new LinearLayout.LayoutParams(72,-2)); itemList.addView(row);
        }
        if(shown==0){TextView e=new TextView(this);e.setText(inventory.isEmpty()?"Aucun article compté. Connecte le C750 puis commence à scanner.":"Aucun résultat.");e.setPadding(10,24,10,24);e.setTextColor(getColor(R.color.muted));itemList.addView(e);}
    }
    private void changeQty(String ean,int d){Inv i=inventory.get(ean);if(i==null)return;i.qty+=d;i.updated=System.currentTimeMillis();if(i.qty<=0)inventory.remove(ean);saveInventory();render();}

    private File file(String name){return new File(getFilesDir(),name);}
    private void saveCatalog(){JSONArray a=new JSONArray();try{for(Product p:catalog.values()){JSONObject o=new JSONObject();o.put("ean",p.ean);o.put("name",p.name);a.put(o);}writeText(file("catalog.json"),a.toString());}catch(Exception ignored){}}
    private void saveInventory(){JSONArray a=new JSONArray();try{for(Inv i:inventory.values()){JSONObject o=new JSONObject();o.put("ean",i.ean);o.put("name",i.name);o.put("qty",i.qty);o.put("updated",i.updated);a.put(o);}writeText(file("inventory.json"),a.toString());}catch(Exception ignored){}}
    private void loadAll(){
        try{JSONArray a=new JSONArray(readText(file("catalog.json")));for(int k=0;k<a.length();k++){JSONObject o=a.getJSONObject(k);Product p=new Product(o.getString("ean"),o.getString("name"));catalog.put(p.ean,p);}}catch(Exception ignored){}
        try{JSONArray a=new JSONArray(readText(file("inventory.json")));for(int k=0;k<a.length();k++){JSONObject o=a.getJSONObject(k);Inv i=new Inv(o.getString("ean"),o.getString("name"),o.getInt("qty"),o.optLong("updated",0));inventory.put(i.ean,i);}}catch(Exception ignored){}
        txtCatalog.setText(getPreferences(MODE_PRIVATE).getString("catalogLabel",catalog.isEmpty()?"Aucun catalogue chargé":catalog.size()+" articles chargés"));
    }
    private static void writeText(File f,String s)throws IOException{try(OutputStreamWriter w=new OutputStreamWriter(new FileOutputStream(f),StandardCharsets.UTF_8)){w.write(s);}}
    private static String readText(File f)throws IOException{if(!f.exists())return "[]";StringBuilder s=new StringBuilder();try(BufferedReader r=new BufferedReader(new InputStreamReader(new FileInputStream(f),StandardCharsets.UTF_8))){String l;while((l=r.readLine())!=null)s.append(l);}return s.toString();}

    private void vibrate(long[] pattern){try{Vibrator v=(Vibrator)getSystemService(VIBRATOR_SERVICE);if(Build.VERSION.SDK_INT>=26)v.vibrate(VibrationEffect.createWaveform(pattern,-1));else v.vibrate(pattern,-1);}catch(Exception ignored){}}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
    @SuppressWarnings("MissingPermission") private void closeGatt(){if(gatt!=null){try{gatt.disconnect();gatt.close();}catch(Exception ignored){}gatt=null;}}
    @Override protected void onDestroy(){super.onDestroy();closeGatt();}
}
