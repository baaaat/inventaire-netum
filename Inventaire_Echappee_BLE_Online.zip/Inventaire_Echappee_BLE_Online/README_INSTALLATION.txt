INVENTAIRE L'ÉCHAPPÉE — ANDROID + NETUM C750 EN BLE
====================================================

CE QUE FAIT CETTE VERSION
-------------------------
Cette application est autonome :
- aucun site web ;
- aucun compte Cloudflare ;
- aucun hébergement OVH ;
- aucun clavier HID ;
- aucun PC à laisser allumé.

Le NETUM C750 transmet directement ses données en Bluetooth BLE à l'application.
L'inventaire et le catalogue sont stockés localement sur la tablette.

AVANT LE PREMIER LANCEMENT
--------------------------
1. Sur le C750, scanner le code de configuration « Bluetooth BLE » du manuel NETUM.
2. FERMER Scanner Studio. Important : Scanner Studio peut conserver la connexion BLE et empêcher une deuxième application de se connecter au scanner.
3. Laisser le Bluetooth activé sur la tablette.

INSTALLER / FABRIQUER L'APK
---------------------------
Le dossier est un projet Android Studio complet.

1. Installer Android Studio sur le PC.
2. Ouvrir Android Studio > Open.
3. Choisir le dossier Inventaire_Echappee_BLE_Android.
4. Attendre la synchronisation Gradle.
5. Menu Build > Build App Bundle(s) / APK(s) > Build APK(s).
6. Android Studio indique l'emplacement de app-debug.apk.
7. Copier cet APK sur la tablette Samsung et l'installer.
   Android pourra demander d'autoriser l'installation d'applications provenant de cette source.

PREMIÈRE UTILISATION
--------------------
1. Ouvrir « Inventaire Échappée ».
2. Appuyer sur « Connecter C750 ».
3. Autoriser « Appareils à proximité » / Bluetooth lorsque la tablette le demande.
4. L'application cherche automatiquement le C750.
   Le C750 peut apparaître sous le nom « RS barcode scanner », « NETUM » ou un nom similaire.
5. Si plusieurs appareils BLE sont trouvés, choisir le scanner dans la liste.
6. Attendre le message : « C750 connecté — prêt à scanner ».
7. Scanner un EAN. Il doit apparaître directement dans l'application.

AUCUN CLAVIER À CONFIGURER
--------------------------
QWERTY/AZERTY n'intervient plus. L'application reçoit les octets BLE directement.
Il est donc normal qu'un scan ne s'écrive pas dans Samsung Notes lorsque le C750 est en BLE.

IMPORTER LE CATALOGUE SHIFTER
------------------------------
Appuyer sur « Importer catalogue CSV » et choisir le fichier export_stock_*.csv.

Le format repris de l'ancienne application est :
- colonne 1 = EAN ;
- colonne 3 = désignation.

Le catalogue reste enregistré dans l'application après fermeture/redémarrage.

INVENTAIRE
----------
À chaque scan :
- article déjà présent : quantité +1 ;
- nouvel article : quantité 1 ;
- EAN absent du catalogue : « EAN inconnu ».

Les boutons + et − permettent de corriger une quantité.
« Annuler dernier scan » annule uniquement le dernier scan effectué.
« Nouvel inventaire » efface les quantités mais conserve le catalogue.

EXPORT
------
« Exporter inventaire.txt » crée un fichier au format :
EAN,quantité;EAN,quantité;...

L'emplacement est choisi via le sélecteur de fichiers Android (Téléchargements, Drive, etc.).

SI LE C750 N'EST PAS TROUVÉ
---------------------------
- vérifier qu'il est bien en mode BLE et non HID/SPP ;
- fermer complètement Scanner Studio ;
- couper/rallumer le C750 ;
- couper/rallumer le Bluetooth de la tablette ;
- relancer « Connecter C750 ».

TEST IMPORTANT
--------------
Une fois connecté, scanner plusieurs fois le code 1234567890.
L'application doit recevoir 1234567890 à chaque fois.
Comme elle ne passe pas par le clavier HID Android, les pertes de chiffres rencontrées précédemment ne doivent plus se produire.

NOTE TECHNIQUE
--------------
L'application découvre les services GATT du scanner et s'abonne automatiquement aux caractéristiques BLE qui annoncent des notifications/indications. Elle ne dépend donc pas d'une disposition de clavier Android.
